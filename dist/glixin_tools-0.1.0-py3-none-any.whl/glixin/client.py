import os
import requests

class GlixinClient:
    def __init__(self, api_key: str = None, base_url: str = None):
        self.api_key = api_key or os.getenv("GLIXIN_API_KEY")
        if not self.api_key:
            raise ValueError("API key must be provided or set via GLIXIN_API_KEY environment variable.")
        
        # Default to Glixin AWS Gateway production endpoint for SPD
        self.base_url = base_url or "https://api.glixin.com/v1"
        self.session = requests.Session()
        self.session.headers.update({
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
            "User-Agent": "glixin-tools/0.1.0"
        })

    def dehydrate_prompt(self, prompt: str, policy: str = "standard") -> dict:
        """
        Submits raw text prompt to the Semiotic Prompt Dehydrator (SPD) API.
        """
        url = f"{self.base_url}/spd/dehydrate"
        payload = {"prompt": prompt, "policy": policy}
        
        response = self.session.post(url, json=payload)
        
        if response.status_code == 401:
            raise PermissionError("Unauthorized: Check your Glixin API key.")
        elif response.status_code == 429:
            raise RuntimeError("Rate limit exceeded. Please check your quarterly tier cap.")
        elif response.status_code >= 500:
            raise RuntimeError(f"Glixin Gateway Error ({response.status_code}): {response.text}")
            
        response.raise_for_status()
        return response.json()